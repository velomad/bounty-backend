const fileFilter = require("./fileFilter")
const fileStorage = require("./fileStorage")

module.exports = {fileFilter, fileStorage}