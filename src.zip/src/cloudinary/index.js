const upload = require("./upload");
const destroy = require("./destroy");

module.exports = { upload, destroy };